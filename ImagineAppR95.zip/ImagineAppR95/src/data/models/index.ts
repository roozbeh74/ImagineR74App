/* eslint import/no-cycle: "off" */
import AppmodelR95 from './appmodelR95.model';

export { AppmodelR95 };
