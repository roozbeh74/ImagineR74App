/* eslint import/no-cycle: "off" */
import { Entity, BaseEntity, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export default class AppmodelR95 extends BaseEntity {
  @PrimaryGeneratedColumn()
  id: number;
}
