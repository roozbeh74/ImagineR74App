import { getRepository } from 'typeorm';
import { AppmodelR95 } from 'data/models';
import { NotFound } from 'server/utils/errors';

export default class AppmodelR95Repository {
  static async create(createBody: {}) {
    const appmodelR95Repository = getRepository(AppmodelR95);
    const createdAppmodelR95: AppmodelR95 = appmodelR95Repository.create(createBody);
    return appmodelR95Repository.save(createdAppmodelR95);
  }

  static get(id: number) {
    const appmodelR95Repository = getRepository(AppmodelR95);
    return appmodelR95Repository.findOne({
      where: { id },
      relations: [],
    });
  }

  static getAll(filters: any) {
    const appmodelR95Repository = getRepository(AppmodelR95);
    return appmodelR95Repository.find({
      where: filters,
      relations: [],
    });
  }

  static getAllByPks(pks: number[]) {
    const appmodelR95Repository = getRepository(AppmodelR95);
    return appmodelR95Repository.findByIds(pks);
  }

  static async update(updateBody: { id: number }) {
    return this.partialUpdate(updateBody);
  }

  static async partialUpdate(updateBody: { id: number }) {
    const appmodelR95Repository = getRepository(AppmodelR95);
    const foundAppmodelR95: AppmodelR95 = await appmodelR95Repository.findOne(updateBody.id);

    if (!foundAppmodelR95)
      throw new NotFound(`AppmodelR95 with primary key ${updateBody.id} not found`);
    await appmodelR95Repository.save(foundAppmodelR95);
    return foundAppmodelR95;
  }

  static async destroy(id: number) {
    const appmodelR95Repository = getRepository(AppmodelR95);
    const foundAppmodelR95 = await appmodelR95Repository.findOne(id);

    if (!foundAppmodelR95) throw new NotFound(`AppmodelR95 with primary key ${id} not found`);

    await appmodelR95Repository.delete(id);
    return foundAppmodelR95;
  }
}
