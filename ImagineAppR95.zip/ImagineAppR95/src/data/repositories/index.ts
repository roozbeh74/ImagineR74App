import AppmodelR95Repository from './appmodelR95.repository';

export { AppmodelR95Repository };
