import AppmodelR95Controller from './appmodelR95.controller';

export { AppmodelR95Controller };
