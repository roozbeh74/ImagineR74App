import { Request, Response, NextFunction } from 'express';
import { CREATED } from 'http-status';
import { AppmodelR95Service } from 'server/services';
import { NotFound } from 'server/utils/errors';

export default class AppmodelR95Controller {
  static async runServiceAction(req: Request, serviceAction: Function) {
    const id = req.params.id !== undefined ? Number(req.params.id) : undefined;
    const {} = req.body;
    if (id !== undefined) {
      return serviceAction({
        id,
      });
    }
    return serviceAction({});
  }

  static async create(req: Request, res: Response, next: NextFunction) {
    try {
      const newAppmodelR95 = await AppmodelR95Controller.runServiceAction(
        req,
        AppmodelR95Service.create,
      );
      res.locals.status = CREATED;
      res.locals.data = newAppmodelR95;
      return next();
    } catch (error) {
      return next(error);
    }
  }

  static async get(req: Request, res: Response, next: NextFunction) {
    try {
      const id: number = Number(req.params.id);
      const appmodelR95Object = await AppmodelR95Service.get(id);
      if (!appmodelR95Object) {
        throw new NotFound(`AppmodelR95 with primary key ${id} not found`);
      }

      res.locals.data = appmodelR95Object;
      return next();
    } catch (error) {
      return next(error);
    }
  }

  static async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const filters = { ...req.query };
      const allAppmodelR95s = await AppmodelR95Service.getAll(filters);
      res.locals.data = allAppmodelR95s;
      return next();
    } catch (error) {
      return next(error);
    }
  }

  static async update(req: Request, res: Response, next: NextFunction) {
    try {
      const updatedAppmodelR95 = await AppmodelR95Controller.runServiceAction(
        req,
        AppmodelR95Service.update,
      );
      res.locals.data = updatedAppmodelR95;

      return next();
    } catch (error) {
      return next(error);
    }
  }

  static async partialUpdate(req: Request, res: Response, next: NextFunction) {
    try {
      const updatedAppmodelR95 = await AppmodelR95Controller.runServiceAction(
        req,
        AppmodelR95Service.partialUpdate,
      );
      res.locals.data = updatedAppmodelR95;
      return next();
    } catch (error) {
      return next(error);
    }
  }

  static async destroy(req: Request, res: Response, next: NextFunction) {
    try {
      const id: number = Number(req.params.id);
      const appmodelR95Delete = await AppmodelR95Service.destroy(id);
      res.locals.data = appmodelR95Delete;

      return next();
    } catch (error) {
      return next(error);
    }
  }
}
