import { AppmodelR95Repository } from 'data/repositories';

export default class AppmodelR95Service {
  static create(createBody: {}) {
    return AppmodelR95Repository.create(createBody);
  }

  static get(id: number) {
    return AppmodelR95Repository.get(id);
  }

  static getAll(args: any) {
    return AppmodelR95Repository.getAll(args);
  }

  static getAllByPks(pks: number[]) {
    return AppmodelR95Repository.getAllByPks(pks);
  }

  static update(updateBody: { id: number }) {
    return AppmodelR95Repository.update(updateBody);
  }

  static partialUpdate(updateBody: { id: number }) {
    return AppmodelR95Repository.partialUpdate(updateBody);
  }

  static destroy(id: number) {
    return AppmodelR95Repository.destroy(id);
  }
}
