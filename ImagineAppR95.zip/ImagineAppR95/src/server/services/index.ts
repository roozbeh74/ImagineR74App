import AppmodelR95Service from './appmodelR95.service';

export { AppmodelR95Service };
