import AdminBro from 'admin-bro';
import { AppmodelR95 } from 'data/models';

const initializeAdminBroRoutes = () =>
  new AdminBro({
    rootPath: '/admin',
    resources: [
      {
        resource: AppmodelR95,
        options: {
          parent: {
            name: 'Database',
            icon: 'Api',
          },
          listProperties: ['id'],
        },
      },
    ],
    branding: {
      companyName: 'Database dashboard',
      softwareBrothers: false,
      logo: false,
      favicon: 'https://imagine.ai/img/favicon.ico',
    },
  });

export default initializeAdminBroRoutes;
