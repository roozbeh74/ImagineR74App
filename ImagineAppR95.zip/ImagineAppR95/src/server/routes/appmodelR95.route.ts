import { Router } from 'express';
import { validate } from 'express-validation';
import { AppmodelR95Controller } from 'server/controllers';
import { appmodelR95Validation, options } from 'server/validations';

const appmodelR95Router = Router();

appmodelR95Router.get(
  '/',
  validate(appmodelR95Validation.getAll, options),
  AppmodelR95Controller.getAll,
);

appmodelR95Router.get('/:id', AppmodelR95Controller.get);

appmodelR95Router.post(
  '/',
  validate(appmodelR95Validation.create, options),
  AppmodelR95Controller.create,
);

appmodelR95Router.put(
  '/:id',
  validate(appmodelR95Validation.update, options),
  AppmodelR95Controller.update,
);

appmodelR95Router.patch(
  '/:id',
  validate(appmodelR95Validation.partialUpdate, options),
  AppmodelR95Controller.partialUpdate,
);

appmodelR95Router.delete(
  '/:id',
  validate(appmodelR95Validation.destroy, options),
  AppmodelR95Controller.destroy,
);

export default appmodelR95Router;
