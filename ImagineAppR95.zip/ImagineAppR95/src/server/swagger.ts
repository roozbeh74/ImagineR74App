const swaggerDocument = {
  swagger: '2.0',
  basePath: '/',
  schemes: ['http'],
  consumes: ['application/json'],
  produces: ['application/json'],
  paths: {
    '/appmodelR95/': {
      get: {
        summary: 'Lists all the appmodelR95s',
        tags: ['appmodelR95'],
        produces: ['application/json'],
        responses: {
          200: {
            description: 'Returns a list',
            schema: {
              $ref: '#/definitions/AppmodelR95',
            },
          },
        },
      },
      post: {
        summary: 'Creates a appmodelR95',
        tags: ['appmodelR95'],
        parameters: [
          {
            name: 'appmodelR95',
            in: 'body',
            required: true,
            schema: {
              $ref: '#/createUpdateDef/CreateUpdateAppmodelR95',
            },
          },
        ],
        produces: ['application/json'],
        responses: {
          201: {
            description: 'Returns a new appmodelR95',
            schema: {
              $ref: '#/createUpdateDef/CreateUpdateAppmodelR95',
            },
          },
        },
      },
    },
    '/appmodelR95/{id}': {
      get: {
        summary: 'Gets a appmodelR95 by its primary key',
        tags: ['appmodelR95'],
        parameters: [
          {
            name: 'id',
            in: 'path',
            required: true,
            type: 'integer',
          },
        ],
        responses: {
          200: {
            description: 'Returns a appmodelR95 with primary key',
            schema: {
              $ref: '#/definitions/AppmodelR95',
            },
          },
        },
      },
      delete: {
        summary: 'Deletes a appmodelR95 by its primary key',
        tags: ['appmodelR95'],
        parameters: [
          {
            name: 'id',
            in: 'path',
            required: true,
            type: 'integer',
          },
        ],
        responses: {
          200: {
            description: 'OK',
          },
        },
      },
      put: {
        summary: 'Overrides the values of a appmodelR95',
        tags: ['appmodelR95'],
        parameters: [
          {
            name: 'id',
            in: 'path',
            required: true,
            schema: {
              $ref: '#/definitions/AppmodelR95',
            },
          },
          {
            name: 'appmodelR95',
            in: 'body',
            required: true,
            schema: {
              $ref: '#/createUpdateDef/CreateUpdateAppmodelR95',
            },
          },
        ],
        responses: {
          200: {
            description: 'Returns a appmodelR95',
            schema: {
              $ref: '#/definitions/AppmodelR95',
            },
          },
        },
      },
      patch: {
        tags: ['appmodelR95'],
        summary: 'patch a appmodelR95',
        parameters: [
          {
            name: 'id',
            in: 'path',
            schema: {
              $ref: '#/definitions/AppmodelR95',
            },
          },
          {
            name: 'appmodelR95',
            in: 'body',
            schema: {
              $ref: '#/createUpdateDef/CreateUpdateAppmodelR95',
            },
          },
        ],
        responses: {
          200: {
            description: 'Returns a appmodelR95 and its partially overwritten values',
            schema: {
              $ref: '#/definitions/AppmodelR95',
            },
          },
        },
      },
    },
  },
  definitions: {
    AppmodelR95: {
      required: [],
      properties: {
        id: {
          type: 'integer',
          format: 'int32',
          uniqueItems: true,
          readOnly: true,
        },
      },
    },
  },
  createUpdateDef: {
    CreateUpdateAppmodelR95: {
      required: [],
      properties: {
        id: {
          type: 'integer',
          format: 'int32',
          uniqueItems: true,
          readOnly: true,
        },
      },
    },
  },
};

export default swaggerDocument;
