import { Joi } from 'express-validation';

const appmodelR95Validation = {
  getAll: {
    query: Joi.object({
      id: Joi.number().integer(),
    }),
  },
  create: {
    body: Joi.object({}),
  },
  update: {
    params: Joi.object({
      id: Joi.number().integer().required(),
    }),
    body: Joi.object({}),
  },
  partialUpdate: {
    params: Joi.object({
      id: Joi.number().integer().required(),
    }),
    body: Joi.object({}),
  },
  destroy: {
    params: Joi.object({
      id: Joi.number().integer().required(),
    }),
  },
};

export default appmodelR95Validation;
