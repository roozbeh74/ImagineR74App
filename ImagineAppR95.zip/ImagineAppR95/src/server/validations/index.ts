import appmodelR95Validation from './appmodelR95.validation';

const options = { keyByField: true };

export { appmodelR95Validation, options };
