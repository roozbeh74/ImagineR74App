import { buildAppmodelR95, createAppmodelR95 } from './appmodelR95.factory';

export { buildAppmodelR95, createAppmodelR95 };
