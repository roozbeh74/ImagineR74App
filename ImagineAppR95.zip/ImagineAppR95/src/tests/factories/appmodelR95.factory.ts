import { getRepository } from 'typeorm';
import { AppmodelR95 } from 'data/models';

interface AppmodelR95Relations {}

async function buildAppmodelR95(appmodelR95: AppmodelR95Relations): Promise<AppmodelR95> {
  const resAppmodelR95 = new AppmodelR95();

  return Promise.resolve(resAppmodelR95);
}

async function createAppmodelR95(fakeAppmodelR95: AppmodelR95): Promise<AppmodelR95> {
  const repository = getRepository(AppmodelR95);
  const appmodelR95 = repository.create(fakeAppmodelR95);
  await repository.save(appmodelR95);

  return appmodelR95;
}

export { buildAppmodelR95, createAppmodelR95 };
