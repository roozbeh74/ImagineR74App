import { expect } from 'chai';
import { getRepository } from 'typeorm';
import request from 'supertest';
import { AppmodelR95 } from 'data/models';
import { app } from 'server/app';
import { buildAppmodelR95, createAppmodelR95 } from './factories';
import { Database, setUpRoutesAndMiddlewares } from './utils';

const ENDPOINT = '/appmodelR95';

describe('AppmodelR95 tests', () => {
  before(async () => {
    await Database.startDatabase();
    setUpRoutesAndMiddlewares();
  });

  after(async () => {
    Database.connection.close();
    Database.dropDatabase();
  });

  beforeEach(async () => {
    await Database.connection.synchronize(true);
  });

  it('Should respond with a new appmodelR95', async () => {
    const appmodelR95Repository = getRepository(AppmodelR95);

    const fakeAppmodelR95 = await buildAppmodelR95({});

    const appmodelR95Body = {
      ...fakeAppmodelR95,
    };

    const response = await request(app).post(ENDPOINT).send(appmodelR95Body);

    expect(response.status).to.equal(201);
    expect(response.statusCode).to.equal(201);

    const responseAppmodelR95 = response.body.data;

    const appmodelR95 = await appmodelR95Repository.findOne(responseAppmodelR95.id, {
      relations: [],
    });
  });

  it('Should respond with a appmodelR95', async () => {
    const appmodelR95 = await buildAppmodelR95({});
    const fakeAppmodelR95 = await createAppmodelR95(appmodelR95);

    const response = await request(app).get(`${ENDPOINT}/${fakeAppmodelR95.id}`);

    const { statusCode, status } = response;
    const { data } = response.body;

    expect(status).to.equal(200);
    expect(statusCode).to.equal(200);

    expect(data.id).to.equal(fakeAppmodelR95.id);
  });

  it('Should throw an error if appmodelR95 was not found', async () => {
    const appmodelR95Repository = getRepository(AppmodelR95);
    const appmodelR95 = await buildAppmodelR95({});
    const fakeAppmodelR95 = await createAppmodelR95(appmodelR95);
    const { id } = fakeAppmodelR95;
    await appmodelR95Repository.delete(fakeAppmodelR95.id);

    const response = await request(app).get(`${ENDPOINT}/${id}`);
    const { statusCode } = response;

    expect(statusCode).to.equal(404);
  });

  it('Should respond with a list of appmodelR95s', async () => {
    const appmodelR95Repository = getRepository(AppmodelR95);
    const response = await request(app).get(ENDPOINT);

    const { statusCode, status } = response;
    const { data } = response.body;

    expect(status).to.equal(200);
    expect(statusCode).to.equal(200);

    const allAppmodelR95s = await appmodelR95Repository.find();
    expect(data.length).to.equal(allAppmodelR95s.length);
  });

  it('Should respond with an updated appmodelR95', async () => {
    const appmodelR95Repository = getRepository(AppmodelR95);

    const appmodelR95 = await buildAppmodelR95({});
    const fakeAppmodelR95 = await createAppmodelR95(appmodelR95);

    const anotherFakeAppmodelR95 = await buildAppmodelR95({});

    const { id } = fakeAppmodelR95;

    const response = await request(app).put(`${ENDPOINT}/${fakeAppmodelR95.id}`).send({});

    const { status } = response;
    const { data } = response.body;

    expect(status).to.equal(200);
    expect(response.statusCode).to.equal(200);

    const updatedAppmodelR95 = await appmodelR95Repository.findOne(id, { relations: [] });
  });

  it('Should not update AppmodelR95, if it does not exist', async () => {
    const appmodelR95Repository = getRepository(AppmodelR95);
    const appmodelR95 = await buildAppmodelR95({});
    const fakeAppmodelR95 = await createAppmodelR95(appmodelR95);
    const { id } = fakeAppmodelR95;
    await appmodelR95Repository.delete(id);

    const response = await request(app).put(`${ENDPOINT}/${id}`).send({});

    const { statusCode } = response;
    expect(statusCode).to.equal(404);
  });

  it('Should respond with an updated appmodelR95 (no updates)', async () => {
    const appmodelR95 = await buildAppmodelR95({});
    const fakeAppmodelR95 = await createAppmodelR95(appmodelR95);

    const response = await request(app).patch(`${ENDPOINT}/${fakeAppmodelR95.id}`).send({});

    const { status } = response;

    expect(status).to.equal(200);
    expect(response.statusCode).to.equal(200);
  });

  it('Should respond with a deleted appmodelR95', async () => {
    const appmodelR95Repository = getRepository(AppmodelR95);
    const appmodelR95 = await buildAppmodelR95({});
    const fakeAppmodelR95 = await createAppmodelR95(appmodelR95);

    const response = await request(app).delete(`${ENDPOINT}/${fakeAppmodelR95.id}`);

    const { status } = response;
    const { data } = response.body;

    expect(status).to.equal(200);
    expect(response.statusCode).to.equal(200);

    expect(data.id).to.equal(fakeAppmodelR95.id);

    const deletedAppmodelR95 = await appmodelR95Repository.findOne(fakeAppmodelR95.id);
    expect(deletedAppmodelR95).to.equal(undefined);
  });

  it('Should not delete AppmodelR95, if it does not exist', async () => {
    const appmodelR95Repository = getRepository(AppmodelR95);
    const appmodelR95 = await buildAppmodelR95({});
    const fakeAppmodelR95 = await createAppmodelR95(appmodelR95);
    const { id } = fakeAppmodelR95;
    await appmodelR95Repository.delete(id);

    const response = await request(app).delete(`${ENDPOINT}/${id}`);

    const { statusCode } = response;
    expect(statusCode).to.equal(404);
  });
});
